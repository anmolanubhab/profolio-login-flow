
  # User Dashboard

  This is a code bundle for User Dashboard. The original project is available at https://www.figma.com/design/vjUcZ2ORX2Y5WC0p0S2k3u/User-Dashboard.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  