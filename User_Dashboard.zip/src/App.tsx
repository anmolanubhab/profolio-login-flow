import { TopNavbar } from './components/TopNavbar';
import { StoriesSection } from './components/StoriesSection';
import { CreatePostCard } from './components/CreatePostCard';
import { PostCard } from './components/PostCard';
import { BottomNavigation } from './components/BottomNavigation';

const posts = [
  {
    id: '1',
    author: {
      name: 'Ajit Kumar',
      avatar: '👨🏻',
    },
    timestamp: '2d ago',
    content: 'Just finished an amazing project with my team! The collaboration was incredible and the results exceeded our expectations. Grateful for this opportunity! 🚀',
    image: 'https://images.unsplash.com/photo-1531545514256-b1400bc00f31?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWFtJTIwY29sbGFib3JhdGlvbiUyMG1lZXRpbmd8ZW58MXx8fHwxNzU5NjUyNzU3fDA&ixlib=rb-4.1.0&q=80&w=1080',
    likes: 42,
    comments: 8,
    shares: 3,
  },
  {
    id: '2',
    author: {
      name: 'Priya Sharma',
      avatar: '👩🏽',
    },
    timestamp: '5h ago',
    content: 'Excited to announce that I\'m speaking at the Tech Innovation Summit next month! Looking forward to sharing insights on digital transformation. 💡',
    likes: 128,
    comments: 24,
    shares: 15,
  },
  {
    id: '3',
    author: {
      name: 'Rahul Mehta',
      avatar: '👨🏽‍💻',
    },
    timestamp: '1d ago',
    content: 'New workspace setup complete! Ready to crush some goals this quarter. What does your ideal workspace look like?',
    image: 'https://images.unsplash.com/photo-1746221331496-a87689fc8eb9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjB3b3Jrc3BhY2UlMjBkZXNrfGVufDF8fHx8MTc1OTY3NzI0M3ww&ixlib=rb-4.1.0&q=80&w=1080',
    likes: 89,
    comments: 12,
    shares: 5,
  },
  {
    id: '4',
    author: {
      name: 'Anushka Verma',
      avatar: '👩🏻‍💼',
    },
    timestamp: '3h ago',
    content: 'Presentation day! Nervous but excited to share our Q4 strategy with the leadership team. Wish me luck! 🎯',
    image: 'https://images.unsplash.com/photo-1549923746-1d28f336cc41?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXNpbmVzcyUyMHByZXNlbnRhdGlvbiUyMG9mZmljZXxlbnwxfHx8fDE3NTk2OTcxODJ8MA&ixlib=rb-4.1.0&q=80&w=1080',
    likes: 156,
    comments: 31,
    shares: 8,
  },
];

export default function App() {
  return (
    <div className="min-h-screen bg-background pb-20 md:pb-0">
      {/* Top Navigation */}
      <TopNavbar />

      {/* Main Content */}
      <main className="pt-20 px-4 max-w-2xl mx-auto">
        {/* Stories Section */}
        <StoriesSection />

        {/* Create Post Card */}
        <CreatePostCard />

        {/* Feed Posts */}
        <div className="space-y-4">
          {posts.map((post) => (
            <PostCard key={post.id} post={post} />
          ))}
        </div>
      </main>

      {/* Bottom Navigation (Mobile Only) */}
      <BottomNavigation />
    </div>
  );
}