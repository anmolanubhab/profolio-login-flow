import { Home, Users, Bell, Briefcase, Search, User } from 'lucide-react';

export function TopNavbar() {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white border-b border-border">
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
        {/* Logo */}
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center">
            <span className="text-white font-semibold text-xl">P</span>
          </div>
          <span className="font-semibold text-foreground">Profolio</span>
        </div>

        {/* Search Bar */}
        <div className="hidden md:flex flex-1 max-w-md mx-8">
          <div className="relative w-full">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search Profolio"
              className="w-full pl-10 pr-4 py-2 bg-input-background rounded-full border border-transparent focus:border-primary focus:outline-none transition-colors"
            />
          </div>
        </div>

        {/* Navigation Icons */}
        <div className="flex items-center gap-2">
          <NavIcon icon={Home} active />
          <NavIcon icon={Users} />
          <NavIcon icon={Bell} badge={3} />
          <NavIcon icon={Briefcase} />
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center cursor-pointer hover:opacity-90 transition-opacity">
            <User className="w-5 h-5 text-white" />
          </div>
        </div>
      </div>
    </nav>
  );
}

interface NavIconProps {
  icon: React.ElementType;
  active?: boolean;
  badge?: number;
}

function NavIcon({ icon: Icon, active, badge }: NavIconProps) {
  return (
    <button
      className={`relative w-10 h-10 rounded-xl flex items-center justify-center transition-colors ${
        active
          ? 'bg-primary/10 text-primary'
          : 'hover:bg-muted text-muted-foreground hover:text-foreground'
      }`}
    >
      <Icon className="w-5 h-5" />
      {badge && (
        <span className="absolute -top-1 -right-1 w-5 h-5 bg-destructive text-white rounded-full flex items-center justify-center text-xs">
          {badge}
        </span>
      )}
    </button>
  );
}