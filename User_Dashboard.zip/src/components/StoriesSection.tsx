import { Plus } from 'lucide-react';

interface Story {
  id: string;
  name: string;
  avatar: string;
  hasStory: boolean;
}

const stories: Story[] = [
  { id: '1', name: 'Anushka', avatar: '👩🏻‍💼', hasStory: true },
  { id: '2', name: 'Rahul', avatar: '👨🏻‍💻', hasStory: true },
  { id: '3', name: 'Priya', avatar: '👩🏽', hasStory: true },
  { id: '4', name: 'Arjun', avatar: '👨🏽‍🦱', hasStory: true },
  { id: '5', name: 'Neha', avatar: '👩🏻', hasStory: true },
];

export function StoriesSection() {
  return (
    <div className="bg-white rounded-2xl p-4 mb-4 shadow-sm">
      <div className="flex gap-3 overflow-x-auto scrollbar-hide pb-2">
        {/* Add Story */}
        <div className="flex flex-col items-center gap-2 min-w-[80px]">
          <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center cursor-pointer hover:scale-105 transition-transform shadow-md">
            <Plus className="w-7 h-7 text-white" />
          </div>
          <span className="text-xs text-foreground">Add Story</span>
        </div>

        {/* Stories */}
        {stories.map((story) => (
          <StoryItem key={story.id} story={story} />
        ))}
      </div>
    </div>
  );
}

function StoryItem({ story }: { story: Story }) {
  return (
    <div className="flex flex-col items-center gap-2 min-w-[80px] cursor-pointer group">
      <div className="relative">
        <div className="absolute inset-0 rounded-full bg-gradient-to-br from-primary via-accent to-primary p-[3px] group-hover:scale-105 transition-transform">
          <div className="w-full h-full rounded-full bg-white p-[2px]">
            <div className="w-full h-full rounded-full bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center text-2xl">
              {story.avatar}
            </div>
          </div>
        </div>
        <div className="w-16 h-16" />
      </div>
      <span className="text-xs text-foreground text-center truncate w-full px-1">
        {story.name}
      </span>
    </div>
  );
}