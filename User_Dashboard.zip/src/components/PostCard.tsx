import { Heart, MessageCircle, Share2, MoreHorizontal } from 'lucide-react';

interface Post {
  id: string;
  author: {
    name: string;
    avatar: string;
  };
  timestamp: string;
  content: string;
  image?: string;
  likes: number;
  comments: number;
  shares: number;
}

interface PostCardProps {
  post: Post;
}

export function PostCard({ post }: PostCardProps) {
  return (
    <div className="bg-white rounded-2xl p-4 mb-4 shadow-sm">
      {/* Post Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-gradient-to-br from-orange-400 to-orange-500 flex items-center justify-center text-2xl">
            {post.author.avatar}
          </div>
          <div>
            <h4 className="text-foreground">{post.author.name}</h4>
            <span className="text-xs text-muted-foreground">{post.timestamp}</span>
          </div>
        </div>
        <button className="w-8 h-8 rounded-full hover:bg-muted flex items-center justify-center transition-colors">
          <MoreHorizontal className="w-5 h-5 text-muted-foreground" />
        </button>
      </div>

      {/* Post Content */}
      <p className="text-foreground mb-4">{post.content}</p>

      {/* Post Image */}
      {post.image && (
        <div className="mb-4 rounded-xl overflow-hidden">
          <img src={post.image} alt="Post content" className="w-full h-auto" />
        </div>
      )}

      {/* Engagement Stats */}
      <div className="flex items-center justify-between text-sm text-muted-foreground mb-3 px-2">
        <span>{post.likes} likes</span>
        <div className="flex gap-3">
          <span>{post.comments} comments</span>
          <span>{post.shares} shares</span>
        </div>
      </div>

      {/* Divider */}
      <div className="h-px bg-border mb-3" />

      {/* Action Buttons */}
      <div className="grid grid-cols-3 gap-2">
        <ActionButton icon={Heart} label="Like" />
        <ActionButton icon={MessageCircle} label="Comment" />
        <ActionButton icon={Share2} label="Share" />
      </div>
    </div>
  );
}

interface ActionButtonProps {
  icon: React.ElementType;
  label: string;
}

function ActionButton({ icon: Icon, label }: ActionButtonProps) {
  return (
    <button className="flex items-center justify-center gap-2 py-2 rounded-xl hover:bg-muted text-muted-foreground hover:text-primary transition-all active:scale-95">
      <Icon className="w-5 h-5" />
      <span>{label}</span>
    </button>
  );
}