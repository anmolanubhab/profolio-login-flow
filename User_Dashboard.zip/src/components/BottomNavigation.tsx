import { Home, Users, Plus, Bell, Briefcase } from 'lucide-react';

export function BottomNavigation() {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 md:hidden">
      <div className="bg-white/80 backdrop-blur-lg border-t border-border">
        <div className="flex items-center justify-around px-4 py-2">
          <NavButton icon={Home} label="Home" active />
          <NavButton icon={Users} label="Network" />
          
          {/* Create Button - Centered and Larger */}
          <button className="relative -mt-8">
            <div className="w-14 h-14 rounded-full bg-gradient-to-br from-primary to-accent shadow-lg flex items-center justify-center hover:scale-105 transition-transform active:scale-95">
              <Plus className="w-7 h-7 text-white" />
            </div>
          </button>
          
          <NavButton icon={Bell} label="Notifications" badge={3} />
          <NavButton icon={Briefcase} label="Jobs" />
        </div>
      </div>
    </nav>
  );
}

interface NavButtonProps {
  icon: React.ElementType;
  label: string;
  active?: boolean;
  badge?: number;
}

function NavButton({ icon: Icon, label, active, badge }: NavButtonProps) {
  return (
    <button className="flex flex-col items-center gap-1 py-2 relative">
      <div className="relative">
        <Icon
          className={`w-6 h-6 transition-colors ${
            active ? 'text-primary' : 'text-muted-foreground'
          }`}
        />
        {badge && (
          <span className="absolute -top-1 -right-1 w-4 h-4 bg-destructive text-white rounded-full flex items-center justify-center text-[10px]">
            {badge}
          </span>
        )}
      </div>
      <span
        className={`text-[10px] transition-colors ${
          active ? 'text-primary' : 'text-muted-foreground'
        }`}
      >
        {label}
      </span>
    </button>
  );
}