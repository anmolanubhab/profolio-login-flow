import { Camera, FileText, Video } from 'lucide-react';

export function CreatePostCard() {
  return (
    <div className="bg-white rounded-2xl p-4 mb-4 shadow-sm">
      {/* Input Section */}
      <div className="flex items-center gap-3 mb-3">
        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-orange-400 to-orange-500 flex items-center justify-center text-xl">
          👨🏻
        </div>
        <input
          type="text"
          placeholder="What's on your mind?"
          className="flex-1 px-4 py-3 bg-input-background rounded-full border border-transparent focus:border-primary focus:outline-none transition-colors"
        />
      </div>

      {/* Divider */}
      <div className="h-px bg-border mb-3" />

      {/* Action Buttons */}
      <div className="grid grid-cols-2 gap-2">
        <ActionButton icon={Camera} label="Photo" color="from-blue-500 to-blue-600" />
        <ActionButton icon={FileText} label="Document" color="from-primary to-accent" />
      </div>
    </div>
  );
}

interface ActionButtonProps {
  icon: React.ElementType;
  label: string;
  color: string;
}

function ActionButton({ icon: Icon, label, color }: ActionButtonProps) {
  return (
    <button className={`flex items-center justify-center gap-2 px-4 py-3 bg-gradient-to-r ${color} rounded-xl text-white hover:opacity-90 transition-all active:scale-95`}>
      <Icon className="w-5 h-5" />
      <span>{label}</span>
    </button>
  );
}